---
name: "Báo lỗi"
about: Mẫu báo lỗi gặp sự cố khi sử dụng hosts
labels: 

---

[//]: # (***Vui lòng nhập thông tin phía dưới dòng có dấu "[//]:" các dòng này sẽ bị ẩn khi đăng bài. Xin cám ơn!)

***Địa chỉ trang web/ứng dụng lỗi***:

* **Lỗi khi bật hosts**: 

[//]: # (Thay thế %screenshot_url% bên dưới với địa chỉ hình ảnh báo lỗi. Ngoài ra, bạn có thể dán trực tiếp ảnh từ clipboard, chúng sẽ tự động được thêm vào.)

<details><summary>Ảnh chụp màn hình:</summary>

![image](%screenshot_url%)
</details><br/>

* **Khi không bật hosts**: 

[//]: # (Thay thế %screenshot_url% bên dưới với địa chỉ hình ảnh khi không sử dụng hosts. Nếu cần, hãy cung cấp ảnh chụp màn hình bên dưới, giống như trên)

<details><summary>Ảnh chụp màn hình:</summary>

![image](%url_of_screenshot%)
</details><br/>

***Chi tiết***:
