---
name: "Thêm mới"
about: Mẫu yêu cầu thêm mới tên miền
labels: 

---

[//]: # (***Vui lòng nhập thông tin phía dưới dòng có dấu "[//]:" các dòng này sẽ bị ẩn khi đăng bài. Xin cám ơn!)

[//]: # (Nếu bạn muốn thêm tên miền mới, vui lòng đưa tên miền vào thẻ bên dưới.)

***Tên miền***:
```

```
