---
name: "Thảo luận"
about: Mẫu thảo luận, đặt câu hỏi
labels: 

---

[//]: # (***Vui lòng nhập thông tin phía dưới dòng có dấu "[//]:" các dòng này sẽ bị ẩn khi đăng bài. Xin cám ơn!)

[//]: # (Hãy nhập nội dung mà bạn muốn thảo luận, rất cám ơn mọi ý kiến đóng góp của bạn!)

***Nội dung***:
